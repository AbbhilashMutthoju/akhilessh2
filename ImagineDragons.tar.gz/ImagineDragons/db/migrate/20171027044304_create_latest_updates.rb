class CreateLatestUpdates < ActiveRecord::Migration[5.1]
  def change
    create_table :latest_updates do |t|
      t.string :latestnews

      t.timestamps
    end
  end
end
