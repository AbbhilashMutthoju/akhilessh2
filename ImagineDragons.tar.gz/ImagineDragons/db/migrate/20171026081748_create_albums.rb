class CreateAlbums < ActiveRecord::Migration[5.1]
  def change
    create_table :albums do |t|
      t.string :album_name
      t.string :year_of_release

      t.timestamps
    end
  end
end
