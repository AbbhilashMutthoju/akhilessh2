class LatestUpdate < ApplicationRecord
end
