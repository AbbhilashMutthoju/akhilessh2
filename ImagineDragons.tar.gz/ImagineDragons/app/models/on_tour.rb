class OnTour < ApplicationRecord
end
