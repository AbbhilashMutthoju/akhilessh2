class Song < ApplicationRecord
  belongs_to :album
end
