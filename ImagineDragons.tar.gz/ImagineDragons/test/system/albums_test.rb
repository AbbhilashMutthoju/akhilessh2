require "application_system_test_case"

class AlbumsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit albums_url
  #
  #   assert_selector "h1", text: "Album"
  # end
end
