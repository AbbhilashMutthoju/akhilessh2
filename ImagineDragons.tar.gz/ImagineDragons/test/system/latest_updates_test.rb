require "application_system_test_case"

class LatestUpdatesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit latest_updates_url
  #
  #   assert_selector "h1", text: "LatestUpdate"
  # end
end
