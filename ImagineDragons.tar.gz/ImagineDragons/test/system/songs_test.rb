require "application_system_test_case"

class SongsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit songs_url
  #
  #   assert_selector "h1", text: "Song"
  # end
end
