require 'test_helper'

class OnToursControllerTest < ActionDispatch::IntegrationTest
  setup do
    @on_tour = on_tours(:one)
  end

  test "should get index" do
    get on_tours_url
    assert_response :success
  end

  test "should get new" do
    get new_on_tour_url
    assert_response :success
  end

  test "should create on_tour" do
    assert_difference('OnTour.count') do
      post on_tours_url, params: { on_tour: { Centre: @on_tour.Centre, Date: @on_tour.Date, Location: @on_tour.Location } }
    end

    assert_redirected_to on_tour_url(OnTour.last)
  end

  test "should show on_tour" do
    get on_tour_url(@on_tour)
    assert_response :success
  end

  test "should get edit" do
    get edit_on_tour_url(@on_tour)
    assert_response :success
  end

  test "should update on_tour" do
    patch on_tour_url(@on_tour), params: { on_tour: { Centre: @on_tour.Centre, Date: @on_tour.Date, Location: @on_tour.Location } }
    assert_redirected_to on_tour_url(@on_tour)
  end

  test "should destroy on_tour" do
    assert_difference('OnTour.count', -1) do
      delete on_tour_url(@on_tour)
    end

    assert_redirected_to on_tours_url
  end
end
