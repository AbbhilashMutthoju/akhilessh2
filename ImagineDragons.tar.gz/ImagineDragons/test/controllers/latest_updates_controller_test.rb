require 'test_helper'

class LatestUpdatesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @latest_update = latest_updates(:one)
  end

  test "should get index" do
    get latest_updates_url
    assert_response :success
  end

  test "should get new" do
    get new_latest_update_url
    assert_response :success
  end

  test "should create latest_update" do
    assert_difference('LatestUpdate.count') do
      post latest_updates_url, params: { latest_update: { latestnews: @latest_update.latestnews } }
    end

    assert_redirected_to latest_update_url(LatestUpdate.last)
  end

  test "should show latest_update" do
    get latest_update_url(@latest_update)
    assert_response :success
  end

  test "should get edit" do
    get edit_latest_update_url(@latest_update)
    assert_response :success
  end

  test "should update latest_update" do
    patch latest_update_url(@latest_update), params: { latest_update: { latestnews: @latest_update.latestnews } }
    assert_redirected_to latest_update_url(@latest_update)
  end

  test "should destroy latest_update" do
    assert_difference('LatestUpdate.count', -1) do
      delete latest_update_url(@latest_update)
    end

    assert_redirected_to latest_updates_url
  end
end
